package com.example.myslash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.myslash.db.DbUsuarios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Register extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    public void Registrarse (View v){

        EditText Name = (EditText) findViewById(R.id.editTextRName);
        EditText firstName = (EditText) findViewById(R.id.editTextRfirstName);
        EditText lastName = (EditText) findViewById(R.id.editTextRlastName);
        EditText userName = (EditText) findViewById(R.id.editTextRuserName);
        EditText Mail = (EditText) findViewById(R.id.editTextRMail);
        EditText Age = (EditText) findViewById(R.id.editTextRAge);
        EditText Number = (EditText) findViewById(R.id.editTextRNumber);
        RadioButton Gender1 = (RadioButton) findViewById(R.id.radioButtonRGender1);
        RadioButton Gender2 = (RadioButton) findViewById(R.id.radioButtonRGender2);
        RadioButton Type1 = (RadioButton) findViewById(R.id.radioButtonRType1);
        RadioButton Type2 = (RadioButton) findViewById(R.id.radioButtonRType2);
        EditText Password = (EditText) findViewById(R.id.editTextRPassword);

        String mensaje = "";
        String Gender = "";
        String Type = "";
        if(false == Gender2.isChecked() & true == Gender1.isChecked()){
            Gender = "Masculino";
        }
        else if (false == Gender1.isChecked() & true == Gender2.isChecked()){
            Gender = "Femenino";
        }
        if(false == Type2.isChecked() & true == Type1.isChecked()){
            Type = "Alumno";
        }
        else if(false == Type1.isChecked() & true == Type2.isChecked()){
            Type = "Profesor";
        }
        if("".equals(Name.getText().toString()) || "".equals(firstName.getText().toString()) ||
                "".equals(lastName.getText().toString()) || "".equals(userName.getText().toString()) ||
                "".equals(Mail.getText().toString()) || "".equals(Age.getText().toString()) ||
                false == Gender1.isChecked() & false == Gender2.isChecked() ||
                false == Type1.isChecked() & false == Type2.isChecked() ||
                "".equals(Number.getText().toString()) || "".equals(Password.getText().toString()))
        {
            mensaje = "Falta un Parametro";
        }
        else {
            boolean TipoCorreo = false;
            String Correo = "";
            for(int x = 0 ; x < Mail.length(); x++){
                if(Mail.getText().charAt(x) == '@'){
                    for(int y = x ; y < Mail.length(); y++){
                        Correo = Correo + Mail.getText().charAt(y);
                    }
                    if("@gmail.com".equals(Correo) || "@hotmail.com".equals(Correo) || "@outlook.com".equals(Correo)){
                        TipoCorreo = true;
                    }
                    break;
                }
            }
            if(Name.length() > 22 || firstName.length() > 15 || lastName.length() > 15 || userName.length() > 20 ||
            TipoCorreo == false || Mail.length() > 25 || Age.length() > 2 || Number.length() != 8 || Password.length() > 30){
                mensaje = "Parametro Erroneo";
                if(Name.length() > 22){mensaje = "Nombre Muy Largo";}
                if(firstName.length() > 15){mensaje = "Apellido Paterno Muy Largo";}
                if(lastName.length() > 15){mensaje = "Apellido Materno Muy Largo";}
                if(userName.length() > 20){mensaje = "Nombre de Usuario Muy Largo";}
                if(TipoCorreo == false){mensaje = "Correo Invalido";}
                if(Mail.length() > 25){mensaje = "Correo Muy Largo";}
                if(Age.length() > 2){mensaje = "Edad Invalida";}
                if(Number.length() != 8){mensaje = "Numero Invalido";}
                if(Password.length() > 30){mensaje = "Contraseña Muy Larga";}
            }else{
                DbUsuarios dbUsuarios = new DbUsuarios(Register.this);
                long id = dbUsuarios.insertarUsuario(userName.getText().toString(), firstName.getText().toString(),
                        lastName.getText().toString(), Mail.getText().toString(), Number.getText().toString(),
                        Gender, Type, Age.getText().toString(), Password.getText().toString());
                if (id > 0){
                    mensaje = "Registro Guardado";
                    }else {
                    mensaje = "Error";
                }

                }

            }
         Toast.makeText(Register.this, mensaje, Toast.LENGTH_SHORT).show();
        }



    public void Volver (View v){
        Intent intent = new Intent (Register.this, Login.class);
        startActivity( intent );
    }
}