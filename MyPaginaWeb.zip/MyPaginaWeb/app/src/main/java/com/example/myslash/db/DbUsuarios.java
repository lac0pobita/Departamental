package com.example.myslash.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

public class DbUsuarios extends Dbhelper {
    Context context;

    public DbUsuarios(@Nullable Context context) {
        super(context);
        this.context = context;
    }
    public long insertarUsuario (String usuario, String nombre, String apellidos, String correo, String numero, String genero, String tipo, String edad, String contrasena) {
        long id = 0;
        try {
            Dbhelper dbhelper = new Dbhelper(context);
            SQLiteDatabase db = dbhelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("usuario", usuario);
            values.put("nombre", nombre);
            values.put("apellidos", apellidos);
            values.put("correo", correo);
            values.put("numero", numero);
            values.put("genero", genero);
            values.put("tipo", tipo);
            values.put("edad", edad);
            values.put("contrasena", contrasena);


            id = db.insert(TABLE_USUARIOS, null, values);


        } catch (Exception ex) {
            ex.toString();
        }
        return id;
    }
}
